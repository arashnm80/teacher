﻿# One-time download of the offline Pyodide engine (needs internet).
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File tools\fetch-pyodide.ps1

param(
  [string]$Version = "0.26.4"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$App = Join-Path $RepoRoot "app"
$Vendor = Join-Path $App "vendor"
$Tmp = Join-Path $Vendor "_tmp_pyodide"
$Dest = Join-Path $Vendor "pyodide"
$Url = "https://github.com/pyodide/pyodide/releases/download/$Version/pyodide-$Version.tar.bz2"
$Archive = Join-Path $Tmp "pyodide.tar.bz2"

New-Item -ItemType Directory -Force -Path $Vendor | Out-Null
if (Test-Path $Tmp) { Remove-Item -Recurse -Force $Tmp }
if (Test-Path $Dest) { Remove-Item -Recurse -Force $Dest }
New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
New-Item -ItemType Directory -Force -Path $Dest | Out-Null

Write-Host "Downloading Pyodide $Version …"
Write-Host $Url
Invoke-WebRequest -Uri $Url -OutFile $Archive -UseBasicParsing

Write-Host "Extracting…"
tar -xjf $Archive -C $Tmp
$Src = Join-Path $Tmp "pyodide"
if (-not (Test-Path (Join-Path $Src "pyodide.js"))) {
  throw "Unexpected archive layout — pyodide.js not found after extract."
}

$files = @(
  "pyodide.js",
  "pyodide.asm.js",
  "pyodide.asm.wasm",
  "python_stdlib.zip",
  "package.json",
  "pyodide-lock.json"
)
foreach ($f in $files) {
  $from = Join-Path $Src $f
  if (Test-Path $from) {
    Copy-Item $from (Join-Path $Dest $f) -Force
    Write-Host "  copied $f"
  } elseif ($f -eq "pyodide-lock.json") {
    Write-Host "  skip missing optional $f"
  } else {
    throw "Required file missing from release: $f"
  }
}

Remove-Item -Recurse -Force $Tmp
Write-Host "OK → $Dest"
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "check-bundle.ps1")
