#!/usr/bin/env bash
# یک‌بار با اینترنت اجرا شود تا موتور پایتون آفلاین شود.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/app"
VER="${PYODIDE_VERSION:-0.26.4}"
TMP="$APP/vendor/_tmp_pyodide"
DEST="$APP/vendor/pyodide"
URL="https://github.com/pyodide/pyodide/releases/download/${VER}/pyodide-${VER}.tar.bz2"

mkdir -p "$APP/vendor"
rm -rf "$TMP" "$DEST"
mkdir -p "$TMP"
echo "Downloading Pyodide ${VER}…"
curl -fL "$URL" -o "$TMP/pyodide.tar.bz2"
tar -xjf "$TMP/pyodide.tar.bz2" -C "$TMP"
SRC="$TMP/pyodide"
mkdir -p "$DEST"
cp "$SRC/pyodide.js" "$SRC/pyodide.asm.js" "$SRC/pyodide.asm.wasm" \
   "$SRC/python_stdlib.zip" "$SRC/package.json" "$DEST/"
if [[ -f "$SRC/pyodide-lock.json" ]]; then
  cp "$SRC/pyodide-lock.json" "$DEST/"
fi
rm -rf "$TMP"
echo "OK → $DEST"
ls -lh "$DEST" | head
