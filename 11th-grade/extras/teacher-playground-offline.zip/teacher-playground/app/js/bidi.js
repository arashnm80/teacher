/**
 * Bidirectional helpers for Persian UI mixed with English/Python snippets.
 *
 * Important: never wrap "1." as a single LTR island. In an RTL line the period
 * becomes the outer (rightmost) glyph and reads as ".1". Split number + dot.
 */

/** Wrap plain text so Latin/code/digits stay LTR inside an RTL sentence (textContent-safe). */
export function ltrIsolate(text) {
  return `⁦${String(text ?? "")}⁩`;
}

/** HTML snippet for an LTR island (code, URL, Latin keyword, bare digits — no trailing dot). */
export function ltrHtml(text) {
  return `<span class="ltr" dir="ltr">${escapeHtml(String(text ?? ""))}</span>`;
}

/**
 * Numbered label for RTL lists/titles: visual "1. عنوان" (digit on the outside, then dot).
 * Do NOT use ltrHtml(`${n}.`) — that renders as ".1" in RTL.
 */
export function indexLabelHtml(n) {
  return (
    `<span class="idx-num" dir="ltr">${escapeHtml(String(n))}</span>` +
    `<span class="idx-dot">.</span>`
  );
}

/**
 * Escape Persian/English mixed copy and wrap Latin/python-ish runs as LTR islands.
 * Use for titles, topics, and other strings that are not full markdown.
 * Digits are wrapped alone (no trailing "." glued into the island).
 */
export function bidiMixHtml(text) {
  const esc = escapeHtml(String(text ?? ""));
  return esc.replace(
    /[A-Za-z][A-Za-z0-9_./()<>+\-]*(?:\(\))?|[0-9]+(?:\.[0-9]+)*/g,
    (m) => `<span class="ltr" dir="ltr">${m}</span>`
  );
}

function escapeHtml(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

// ---------------------------------------------------------------------------
// Markdown-lite for the playground (statement, hints, guide, solutions).
//
// Persian text is the base direction. Every Latin run (English word, name,
// quoted string, operator) becomes an LTR island, so it keeps its order and
// its punctuation. Code blocks are LTR; the Persian parts inside them (Python
// comments, Persian strings) become RTL islands, so they read correctly too.
// ---------------------------------------------------------------------------

/** Latin runs with their quotes and inner punctuation (same rule as the lesson site). */
const LATIN_RUN =
  /["“]?[A-Za-z][A-Za-z0-9_.\-+#\/:\\'"“”’()\[\]{}=;,!?@$%*\s]*[A-Za-z0-9)\]}"”’!?%]|["“]?[A-Za-z]/g;
/** Persian words, joined by spaces or punctuation (Persian text inside code). */
const PERSIAN_RUN =
  /[؀-ۿ‌‍]+(?:[\s،؛؟.:!«»()\-]+[؀-ۿ‌‍]+)*/g;
const HAS_PERSIAN = /[؀-ۿ]/;

/** Escape text and wrap every Latin run in an LTR island. */
export function isolateLatin(text) {
  const src = String(text ?? "");
  let out = "";
  let last = 0;
  for (const m of src.matchAll(LATIN_RUN)) {
    out += escapeHtml(src.slice(last, m.index));
    out += `<span class="ltr" dir="ltr">${escapeHtml(m[0])}</span>`;
    last = m.index + m[0].length;
  }
  return out + escapeHtml(src.slice(last));
}

/** One paragraph or list item: `code`, **bold**, and Latin islands in the rest. */
export function inlineMd(text) {
  return String(text ?? "")
    .split(/(`[^`]+`)/g)
    .map((part, i) => {
      if (i % 2 === 1) {
        return `<code class="ltr" dir="ltr">${escapeHtml(part.slice(1, -1))}</code>`;
      }
      return part
        .split(/(\*\*[^*]+\*\*)/g)
        .map((seg, j) =>
          j % 2 === 1 ? `<strong>${isolateLatin(seg.slice(2, -2))}</strong>` : isolateLatin(seg)
        )
        .join("");
    })
    .join("");
}

/**
 * Text for a <pre> (LTR). Persian runs become RTL islands. With comments on,
 * a Python comment (the «#» outside quotes) keeps its «#» on the code side and
 * its Persian text in an RTL island, so the sentence reads in Persian order.
 */
export function codeHtml(text, { comments = true } = {}) {
  return String(text ?? "")
    .split("\n")
    .map((line) => codeLine(line, comments))
    .join("\n");
}

/** Tiny markdown subset: paragraphs, `code`, ``` fences, **bold**, lists. */
export function mdLite(src) {
  const parts = String(src || "").replace(/\r\n/g, "\n").split(/```/);
  let html = "";
  for (let i = 0; i < parts.length; i++) {
    if (i % 2 === 1) {
      const body = parts[i].replace(/^\w*\n/, "").replace(/\n$/, "");
      html += `<pre class="ltr" dir="ltr"><code>${codeHtml(body)}</code></pre>`;
      continue;
    }
    for (const block of parts[i].split(/\n{2,}/)) {
      const trimmed = block.trim();
      if (!trimmed) continue;
      if (/^[-*] /.test(trimmed)) {
        const items = trimmed
          .split(/\n/)
          .map((line) => line.replace(/^[-*] /, "").trim())
          .filter(Boolean)
          .map((line) => `<li>${inlineMd(line)}</li>`)
          .join("");
        html += `<ul>${items}</ul>`;
      } else {
        html += `<p>${inlineMd(trimmed).replaceAll("\n", "<br>")}</p>`;
      }
    }
  }
  return html;
}

function codeLine(line, comments) {
  const cut = comments ? commentStart(line) : -1;
  if (cut < 0) return codeSpans(line);
  const code = codeSpans(line.slice(0, cut));
  const body = line.slice(cut + 1); // everything after the «#»
  if (!HAS_PERSIAN.test(body)) return code + escapeHtml("#" + body);
  // The «#» stays on the code side, on the left. The rest of the comment (Persian,
  // English or both) is one RTL island to its right: Persian runs right-to-left,
  // and English runs stay LTR islands in their own order.
  const lead = body.match(/^\s*/)[0];
  const tail = body.match(/\s*$/)[0];
  const core = body.trim();
  return (
    code +
    "#" +
    escapeHtml(lead) +
    `<span class="cm-fa" dir="rtl">${isolateLatin(core)}</span>` +
    escapeHtml(tail)
  );
}

function codeSpans(code) {
  let out = "";
  let last = 0;
  for (const m of code.matchAll(PERSIAN_RUN)) {
    out += escapeHtml(code.slice(last, m.index));
    out += `<span class="cm-fa" dir="rtl">${escapeHtml(m[0])}</span>`;
    last = m.index + m[0].length;
  }
  return out + escapeHtml(code.slice(last));
}

/** Index of a Python comment's «#» (outside quotes), or -1. */
function commentStart(line) {
  let quote = "";
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (quote) {
      if (ch === "\\") i++;
      else if (ch === quote) quote = "";
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else if (ch === "#") {
      return i;
    }
  }
  return -1;
}
